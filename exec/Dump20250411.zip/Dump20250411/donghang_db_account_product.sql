-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12a701.p.ssafy.io    Database: donghang_db
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_product`
--

DROP TABLE IF EXISTS `account_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_product` (
  `interest_rate` double NOT NULL,
  `account_product_id` bigint NOT NULL AUTO_INCREMENT,
  `bank_id` bigint NOT NULL,
  `max_subscription_balance` bigint DEFAULT NULL,
  `min_subscription_balance` bigint DEFAULT NULL,
  `subscription_period` bigint DEFAULT NULL,
  `account_product_description` varchar(255) NOT NULL,
  `account_product_name` varchar(255) NOT NULL,
  `rate_description` varchar(255) DEFAULT NULL,
  `account_product_type` enum('DEMAND','DEPOSIT','INSTALLMENT') NOT NULL,
  PRIMARY KEY (`account_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_product`
--

LOCK TABLES `account_product` WRITE;
/*!40000 ALTER TABLE `account_product` DISABLE KEYS */;
INSERT INTO `account_product` VALUES (0.3,1,3,NULL,NULL,NULL,'샘플 자유 입출금 통장입니다.','샘플 자유 입출금 통장','자유입출금이므로 낮은 이율','DEMAND'),(5,2,3,10000000,1,12,'샘플 예금 통장입니다.','샘플 예금 통장','1년 동안 5.0%의 이율','DEPOSIT'),(5,3,1,10000000,1,12,'샘플 적금 통장입니다.','샘플 적금 통장','1년 동안 5.0%의 이율','INSTALLMENT'),(3.2,1973,1,50000000,1000000,12,'노인 우대, 비과세 혜택 제공, 12개월 단기 자금 운용에 적합한 예금 상품','노인우대 정기예금 1호','연 3.2% 고정금리, 비과세 적용','DEPOSIT'),(3.5,1974,3,70000000,5000000,24,'고령자 장기 자산 관리용, 노인 전용 우대금리, 연 3.5% 적용','든든한 노후 정기예금','24개월 예치 시 연 3.5% 우대','DEPOSIT'),(2.8,1975,2,30000000,1000000,6,'단기 유동성 확보에 적합, 6개월 예치, 건강 지출 대비 가능','실버 케어 예금','6개월 예치 시 연 2.8%','DEPOSIT'),(3,1976,3,40000000,2000000,12,'만 60세 이상 고객 전용, 의료비 등 예상 지출 대비용 상품','행복한 노후 예금','연 3.0% 고정금리 제공','DEPOSIT'),(3.4,1977,1,60000000,10000000,36,'노후 준비용 장기 예금, 세제 혜택 포함, 복지카드 소지자 우대','미래 준비 정기예금','3년 예치 시 연 3.4%','DEPOSIT'),(3.1,1978,2,50000000,3000000,18,'의료비 대비 목적, 건강 관리 자금 운용 추천, 18개월 중기 상품','실버 건강 예금','18개월 예치 시 연 3.1%','DEPOSIT'),(3.3,1979,3,55000000,2000000,24,'노년기 자산 보호, 비과세 가능, 중도 해지 시 일부 이자 보장','노후안심 예금','연 3.3%, 중도 해지 시 일부 이자 제공','DEPOSIT'),(2.9,1980,3,35000000,500000,6,'단기 자금 운용 목적, 예기치 못한 지출 대비 유동성 중심 상품','단기 안심 예금','6개월 예치 시 연 2.9%','DEPOSIT'),(3.6,1981,3,80000000,10000000,36,'연금 대체용 고령자 전용 장기 상품, 세제 혜택 가능, 장기 고정금리','실버 연금 예금','3년 예치 시 연 3.6%, 비과세 가능','DEPOSIT'),(3.25,1982,1,45000000,2000000,12,'복지카드 소지 노인 전용, 소득세 비과세, 단기 운용 가능 상품','복지우대 예금','연 3.25%, 복지 우대 조건 충족 시 추가금리','DEPOSIT'),(3.4,1983,1,40000000,1000000,12,'일반 직장인 대상, 12개월 만기 단기 운용 적합','스마트 정기예금','연 3.4% 고정금리, 중도 해지 시 일부 이자 지급','DEPOSIT'),(3.6,1984,1,70000000,5000000,24,'장기 자산 운용 목표의 안정형 예금 상품','플랜24 정기예금','24개월 예치 시 연 3.6%','DEPOSIT'),(3.1,1985,2,30000000,1000000,6,'단기 여유 자금 운용용, 6개월 간편 예금','이지 정기예금','6개월 예치 시 연 3.1%','DEPOSIT'),(3.7,1986,1,80000000,5000000,36,'결혼 자금, 장기 자산 축적에 적합한 예금 상품','드림웨딩 정기예금','3년 예치 시 연 3.7%','DEPOSIT'),(3.2,1987,1,20000000,500000,12,'사회초년생 대상, 소액 목돈 마련 예금','스타터 정기예금','연 3.2%, 소액 적합','DEPOSIT'),(3.5,1988,3,60000000,3000000,18,'중기 운용 추천, 자녀 교육비 준비용 예금','에듀 정기예금','18개월 예치 시 연 3.5%','DEPOSIT'),(2.9,1989,2,25000000,1000000,3,'초단기 자금 운용, 유동성 확보 중심 상품','플렉스 예금','3개월 예치 시 연 2.9%','DEPOSIT'),(3.8,1990,2,100000000,10000000,36,'고수익 목표 장기 예금, 안정적 자산 증식','프라임 정기예금','3년 예치 시 연 3.8%','DEPOSIT'),(3.3,1991,3,50000000,2000000,12,'자유로운 자금 운용 가능, 중도해지 수수료 적음','프리 정기예금','연 3.3%, 유연한 해지 가능','DEPOSIT'),(3,1992,1,15000000,500000,6,'단기 자금 활용, 소상공인 대상 추천 상품','비즈 정기예금','6개월 예치 시 연 3.0%','DEPOSIT'),(3.45,1993,2,45000000,1000000,12,'중산층 직장인 대상, 안정적 단기 운용','안심 정기예금','연 3.45% 고정금리','DEPOSIT'),(3.6,1994,3,60000000,3000000,24,'가족 단위 저축 추천, 생활비 예치에 적합','해피 패밀리 예금','24개월 예치 시 연 3.6%','DEPOSIT'),(3.25,1995,1,35000000,1000000,9,'단기와 중기의 중간 옵션, 월급 저축에 적합','밸런스 예금','9개월 예치 시 연 3.25%','DEPOSIT'),(3.55,1996,2,80000000,10000000,36,'자산가 대상 고금리 상품, 대규모 예치 추천','프리미엄 정기예금','3년 예치 시 연 3.55%','DEPOSIT'),(3.15,1997,3,40000000,1000000,12,'대학생, 청년 우대 가능, 진로 준비 지원 예금','청춘 정기예금','연 3.15%, 청년 인증 시 추가 금리','DEPOSIT'),(3,1998,3,30000000,2000000,6,'단기 현금 유동성 중심, 스타트업 추천 예금','런칭 정기예금','6개월 예치 시 연 3.0%','DEPOSIT'),(3.65,1999,1,70000000,5000000,30,'자녀 교육비 및 장기 생활비 확보용','파워세이브 정기예금','30개월 예치 시 연 3.65%','DEPOSIT'),(3.2,2000,1,28000000,1000000,12,'가족 의료비 및 갑작스러운 지출 대비','케어플랜 정기예금','연 3.2%, 중도해지 수수료 면제 조건 있음','DEPOSIT'),(2.95,2001,2,20000000,500000,3,'초단기용, 앱으로 가입 가능, 모바일 특화 상품','모바일 정기예금','3개월 예치 시 연 2.95%','DEPOSIT'),(3.4,2002,1,65000000,3000000,18,'부부 공동 저축 추천, 생활 안정 기반','투게더 정기예금','18개월 예치 시 연 3.4%','DEPOSIT');
/*!40000 ALTER TABLE `account_product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11  9:05:27
