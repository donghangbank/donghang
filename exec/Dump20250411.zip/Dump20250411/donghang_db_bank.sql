-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12a701.p.ssafy.io    Database: donghang_db
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `modified_at` datetime(6) NOT NULL,
  `logo_url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1,'2025-04-07 13:25:01.333573','2025-04-07 13:25:01.333573','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/ac798e9397d9462d91e34b118605b4f0.png','국민은행'),(2,'2025-04-07 13:25:18.428973','2025-04-07 13:25:18.428973','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/2e2fbd8d7775432d9119666dcc188d15.png','신한은행'),(3,'2025-04-07 13:25:29.055615','2025-04-07 13:25:29.055615','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/f0bda7d7a5d4477f91aae47ea4b81d08.png','하나은행'),(4,'2025-04-07 13:25:41.125123','2025-04-07 13:25:41.125123','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/46e51b132e464bb4b8bcb585d2891fcd.png','우리은행'),(5,'2025-04-07 13:25:53.462130','2025-04-07 13:25:53.462130','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/e2ebfb68c90f4a089acae535706366a5.png','IBK기업은행'),(6,'2025-04-07 13:26:03.722716','2025-04-07 13:26:03.722716','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/2299ff6e3c104cb28cef2c6c625700fe.png','케이뱅크'),(7,'2025-04-07 13:26:21.947105','2025-04-07 13:26:21.947105','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/f971a9a5c29445b7aaaaf2380e3d8a48.png','토스뱅크'),(8,'2025-04-07 13:26:31.604552','2025-04-07 13:26:31.604552','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/f4ef64a59978450f93f0f756698ef494.png','카카오뱅크'),(9,'2025-04-07 13:26:39.310620','2025-04-07 13:26:39.310620','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/fb6de5dc898e489291ddfcfcefa000a9.png','농협은행'),(10,'2025-04-07 13:26:58.566090','2025-04-07 13:26:58.566090','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/5c8ae6e523d74d2e8447c6e33f4194f8.png','SC제일은행'),(11,'2025-04-07 13:45:59.077150','2025-04-07 13:45:59.077150','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/1394e54bc433416fa63ca609d810263c.png','SC제일은행'),(12,'2025-04-09 12:58:33.705989','2025-04-09 12:58:33.705989','https://donghang-bucket-dev.s3.ap-northeast-2.amazonaws.com/bank/a8abc0ef2aa74e4eac905b5cc009cc0d.png','하나은행');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11  9:05:29
