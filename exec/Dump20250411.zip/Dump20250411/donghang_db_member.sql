-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12a701.p.ssafy.io    Database: donghang_db
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `birthday` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `modified_at` datetime(6) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `post_number` varchar(255) NOT NULL,
  `member_status` enum('ACTIVE','BLOCKED','DELETED','INACTIVE') NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('1990-05-20 00:00:00.000000','2025-03-26 12:37:28.000000',1,'2025-03-26 12:37:28.000000','서울특별시 강남구 테헤란로 123','hong@example.com','홍길동','010-1234-5678','06164','ACTIVE'),('1995-05-20 00:00:00.000000','2025-04-02 16:13:27.000000',2,'2025-04-02 16:13:27.000000','서울특별시 강남구','hong@example.com','홍길동','010-1234-5678','12345','ACTIVE'),('1998-04-29 00:00:00.000000','2024-08-09 10:12:13.000000',3,'2024-08-09 10:12:13.000000','서울시 강남구 역삼동 123','jonghaparkdevelop@ssafy.com','박종하','01076884473','06234','ACTIVE'),('1999-12-04 00:00:00.000000','2024-07-21 10:12:13.000000',4,'2024-07-21 10:12:13.000000','부산시 해운대구 우동 456','raonrabbit@ssafy.com','최준혁','01040004887','48095','ACTIVE'),('1999-03-20 00:00:00.000000','2023-02-16 05:44:55.000000',5,'2023-02-16 05:44:55.000000','대전시 서구 둔산동 789','cmh1199@ssafy.com','이주현','01040690298','35221','ACTIVE');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11  9:05:30
